<template>
  <div class="filler">
    <br>
  </div>
</template>

<style>
.filler{
      height: 10px;
}
</style>